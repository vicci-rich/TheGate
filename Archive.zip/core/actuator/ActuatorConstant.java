package org.tron.core.actuator;

public class ActuatorConstant {

  public static final String ACCOUNT_EXCEPTION_STR = "Account[";
  public static final String WITNESS_EXCEPTION_STR = "Witness[";
  public static final String PROPOSAL_EXCEPTION_STR = "Proposal[";
  public static final String NOT_EXIST_STR = "] not exists";
}
