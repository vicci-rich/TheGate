package org.tron.core.capsule;

public class BlockIdentifierCapsule {

}
