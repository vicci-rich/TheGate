package org.tron.core.exception;

public class SignatureFormatException extends TronException {

  public SignatureFormatException() {
    super();
  }

  public SignatureFormatException(String message) {
    super(message);
  }

}
