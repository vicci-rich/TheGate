package org.tron.core.exception;

public class ContractExeException extends TronException {

  public ContractExeException() {
    super();
  }

  public ContractExeException(String message) {
    super(message);
  }

}
