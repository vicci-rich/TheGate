package org.tron.core.exception;

public class BadNumberBlockException extends TronException {

  public BadNumberBlockException() {
    super();
  }

  public BadNumberBlockException(String message) {
    super(message);
  }
}
