package org.tron.core.exception;

public class ContractSizeNotEqualToOneException extends ContractValidateException {

  public ContractSizeNotEqualToOneException() {
    super();
  }

  public ContractSizeNotEqualToOneException(String message) {
    super(message);
  }
}
