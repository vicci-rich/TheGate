package org.tron.core.exception;

public class BadBlockException extends TronException {

  public BadBlockException() {
    super();
  }

  public BadBlockException(String message) {
    super(message);
  }
}
