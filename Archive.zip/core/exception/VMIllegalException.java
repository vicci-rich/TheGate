package org.tron.core.exception;

public class VMIllegalException extends TronException {

  public VMIllegalException() {
    super();
  }

  public VMIllegalException(String message) {
    super(message);
  }

}
