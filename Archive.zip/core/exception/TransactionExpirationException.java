package org.tron.core.exception;

public class TransactionExpirationException extends TronException {

  public TransactionExpirationException() {
    super();
  }

  public TransactionExpirationException(String message) {
    super(message);
  }

}