package org.tron.core.exception;

public class HeaderNotFound extends StoreException {

  public HeaderNotFound() {
    super();
  }

  public HeaderNotFound(String message) {
    super(message);
  }
}
