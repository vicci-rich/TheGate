package org.tron.core.exception;

public class ValidateBandwidthException extends TronException {

  public ValidateBandwidthException() {
    super();
  }

  public ValidateBandwidthException(String message) {
    super(message);
  }

}