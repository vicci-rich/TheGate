package org.tron.common.utils;

public interface Quitable extends AutoCloseable {

}
