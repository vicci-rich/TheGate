package org.tron.common.logsfilter.capsule;

public class TriggerCapsule {

  public void processTrigger() {
    throw new UnsupportedOperationException();
  }
}
